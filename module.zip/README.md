# sirnilocs-stash-dc20
 Just a few helpers I use across modules.

Current Release includes Custom Weapon Style registration, a few additional events/triggers, and more!